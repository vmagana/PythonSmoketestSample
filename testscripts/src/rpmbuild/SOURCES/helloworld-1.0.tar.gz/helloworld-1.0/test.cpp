#include <iostream>

using namespace std;


int main ()
{

  cout<<"HELLO WORLD OF TEST RPM"<<endl;

  return 0;

}


